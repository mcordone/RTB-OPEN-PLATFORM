
package com.aol.platforms.rtbgateway.exchanges.translator.data.openrtb;

import javax.annotation.Generated;

@Generated("org.jsonschema2pojo")
public class Regs {

    private int coppa;

    public int getCoppa() {
        return coppa;
    }

    public void setCoppa(int coppa) {
        this.coppa = coppa;
    }

}
