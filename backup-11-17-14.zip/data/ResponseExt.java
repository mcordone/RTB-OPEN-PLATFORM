
package com.aol.platforms.rtbgateway.exchanges.translator.data.openrtb;

import javax.annotation.Generated;

@Generated("org.jsonschema2pojo")
public class ResponseExt {


}
